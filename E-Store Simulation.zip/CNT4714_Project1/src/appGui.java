/* Name: <Nasser Aladawani>
Course: CNT 4714 – Spring 2024
Assignment title: Project 1 – An Event-driven Enterprise Simulation
Date: Sunday January 28, 2024
*/
import java.io.IOException;

public class appGui {
  
    public static void main(String[] args) throws IOException {

        myFrame6 frame= new myFrame6("inventory.csv");

    }

}
